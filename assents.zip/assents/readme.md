HumanAtack


Em um mundo de caos e destruição, apos um apocalipse onde um virus dizimou 97% da população mundial os humanos lutam para sobreviver contra os zumbie, apos 150 anos de luta os humanos passaram a controlar a população zumbie, porem em meio a estes zumbie ouve um casso especifico onde uma familia foi infectada porem não teve sua consciência desvaiada e passou por mutações, entre essa familia de 3 membros tem.

    - A mae chamada Ana B. com fortes vínculos familiares, pratica Iogo todos os dias, tem um bom dialogo e tem uma flexibilidade e adaptação muito grandes, como habilidade possue:
              
           lvl personagem: 1 1.3     Atributos: HP:150, FORÇA: 15, SP: 50
        - Pode esticar membros para atacar humanos = 10 consumo 10
        - Pode induzir humanos a lutarem um contra os outros = consumo 20
        - Possui uma alta probabilidade de fuga = consumo 0 (70%)


    - O pai chamado Luis H. Altas habilidade técnicas que o ajudam a produzir armas que o assistência durante o combate, pode gerar clones para lutar enquanto ele foge.

            lvl personagem: 1 1.3    Atributos: HP:200, FORÇA: 20, SP: 50
        - Tecnomancer: pode abrir e fechar portas e alterar rotas. 10
        - Utilizar armas: produzidas (produz um arma aleatória que possui um dano indefinido) 20
        - Duplicata: possibilita fazer um clone de si mesmo para fulga (80%) 0

    - O filho chamado Lucas A.possui uma grande furtividade e possui um pet que o assistência durante os combate, Lucas pode controlar qualquer humanos apos tranformalo em zumbi.
            
               lvl personagem: 1 1.3    Atributos: hp:100, força: 5, SP: 50
            
            stack(1) +1 para cada adversário transformado
         - Furtividade: pode avançar para o proximo estagio sem ser notado %30 5
         - Pet Attack: pode chamar um des seus zumbeis para atacar os humanos durante o combate: 15 Critico(40%) : 5 (60%)
         - Transformar: transforma o alvo em zumbi apos derrotar o inimigo 20SP (25%)


    Durante uma viagem para fugir dos humanos, a familia de zumbis entram em um antigo shopping que estava com todas as janelas lacradas e aparentemente nenhum sinal de vida, ao entrar no shoppin parte da construção desmorona, e a familia é divida onde o pai ficou no primeiro andar a mae com sua elasticidade consegui subir um andar, porem o filho caiu para o subsolo, todas o caminho entre os membros da familia foi bloqueado, a ultima coisa que a mae conseguiu gritar foi "Nos vemos do outro lado do shopping, porem neste momento a familia de zumbi ovil um grito vindo de um grupo de humanos "Peguem esses vermes malditos", bloqueiem todas as salas e acabem com a raça deles, aqui damos inicio a essa incrível jornada para sobrevivência desta familia diferente.
    









            
